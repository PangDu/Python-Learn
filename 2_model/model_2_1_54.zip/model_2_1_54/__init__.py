def func():
    print("zip文件中!")